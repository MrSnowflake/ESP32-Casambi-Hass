# ESP32 Casambi Controller for Home Assistant

Custom Home Assistant integration for the [akumap/esp32-casambi](https://github.com/akumap/esp32-casambi) firmware (a fork of [lian/esp32-casambi](https://github.com/lian/esp32-casambi)) — an offline ESP32 BLE controller for Casambi lighting.

Each Casambi unit is exposed as a `light` entity with:

- **On/off** and **brightness**, read live from the controller (pushed from the Casambi BLE mesh, not just commands sent by Home Assistant)
- **Color temperature**, for fixtures that report `cctMin`/`cctMax` (converted to Kelvin)
- **Auth support** — the `X-API-Key` token is derived from your Casambi network password, matching the controller's authentication scheme

## Requirements

- An ESP32 running the [akumap/esp32-casambi](https://github.com/akumap/esp32-casambi) firmware (v1.3+ of the ESP↔FHEM interface), provisioned and reachable on your network
- Home Assistant 2024.8 or newer

## Installation via HACS

1. HACS → the three-dot menu (top right) → **Custom repositories**
2. Add this repository URL, category **Integration**
3. Find **ESP32 Casambi Controller** in HACS and install it
4. Restart Home Assistant
5. **Settings → Devices & Services → Add Integration** → search for "ESP32 Casambi"
6. Enter the controller's IP address and (if configured on the controller) its Casambi network password

## What this integration does *not* do (yet)

- No WebSocket push client — state is polled via `GET /api/units` every 10 seconds. Since that endpoint already reports live values, this gives near-real-time state without needing a persistent WebSocket connection, but it isn't as instant as the firmware's own WebSocket push (sub-100ms).
- No vertical light distribution or RGB color control exposed as entities (these don't map cleanly onto Home Assistant's light model).
- No scene or group entities — only individual units.

Contributions welcome.

## License

MIT
