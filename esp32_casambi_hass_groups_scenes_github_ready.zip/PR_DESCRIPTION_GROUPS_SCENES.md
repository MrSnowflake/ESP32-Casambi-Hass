# Add Casambi groups and scenes support

## Summary

This PR adds Home Assistant support for Casambi groups and scenes exposed by the `akumap/esp32-casambi` REST API.

## What changed

- Adds `GET /api/groups` support to the API client and coordinator.
- Adds `GET /api/scenes` support to the API client and coordinator.
- Exposes Casambi groups as dimmable Home Assistant `light` entities.
- Exposes Casambi scenes as native Home Assistant `scene` entities.
- Adds optional scene light-control entities so scenes can also be controlled with `on`, `off` and `brightness/level`.
- Adds API client methods for:
  - `POST /api/scenes/:id/on`
  - `POST /api/scenes/:id/off`
  - `POST /api/scenes/:id/level`
  - `POST /api/groups/:id/level`
  - `POST /api/groups/:id/vertical`
  - `POST /api/groups/:id/slider`
  - `POST /api/units/:id/state`
- Keeps existing `X-API-Key` authentication behavior.
- Adds German and English config-flow translations.

## Notes / design decisions

- The firmware documentation describes group `level`, `vertical` and `slider` endpoints, but no group `/off` endpoint. Therefore `turn_off` for group entities sends level `0`.
- Home Assistant native `scene` entities do not support brightness. To support the ESP32 scene `/level` endpoint, scenes are also exposed as light-control entities.
- The atomic `/api/units/:id/state` endpoint is exposed as an entity service for unit light entities.

## Testing performed

- Python syntax check via `python -m compileall` passed for all files in `custom_components/esp32_casambi`.
- ZIP archive integrity check passed.

## Manual test checklist

- [ ] Install/update the custom component in Home Assistant.
- [ ] Restart Home Assistant.
- [ ] Confirm existing unit lights still appear and can be controlled.
- [ ] Confirm groups from `GET /api/groups` appear as light entities.
- [ ] Confirm group brightness calls `/api/groups/:id/level`.
- [ ] Confirm group vertical/slider services call the matching endpoints.
- [ ] Confirm scenes from `GET /api/scenes` appear as native scene entities.
- [ ] Confirm scene light-control entities support on/off/brightness.
- [ ] Confirm authenticated ESP32 setup works with `X-API-Key`.

## Breaking changes

None intended.
