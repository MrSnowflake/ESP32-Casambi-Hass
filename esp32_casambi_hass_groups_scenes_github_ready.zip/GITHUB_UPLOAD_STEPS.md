# GitHub Upload / PR Schritte

## Variante A: Dateien manuell hochladen

1. ZIP `esp32_casambi_hass_groups_scenes.zip` herunterladen und entpacken.
2. Inhalt in dein lokales GitHub Repository kopieren.
3. Änderungen committen:

```bash
git checkout -b feature/groups-scenes
git add custom_components/esp32_casambi README-GROUPS-SCENES.md
git commit -F COMMIT_MESSAGE_GROUPS_SCENES.txt
git push origin feature/groups-scenes
```

4. Auf GitHub einen Pull Request öffnen.
5. Inhalt aus `PR_DESCRIPTION_GROUPS_SCENES.md` als PR-Beschreibung verwenden.

## Variante B: Wenn Copilot GitHub-Zugriff bekommt

Wenn ein GitHub Connector mit Schreibrechten verfügbar ist, kann Copilot grundsätzlich diese Schritte für dich übernehmen:

1. Repository öffnen.
2. Einen neuen Branch `feature/groups-scenes` erstellen.
3. Dateien aus dem ZIP in den Branch schreiben.
4. Commit mit der vorbereiteten Commit Message erstellen.
5. Branch pushen.
6. Pull Request mit der vorbereiteten Beschreibung öffnen.

Wichtig: Dafür benötigt der Connector Schreibrechte auf dein Repository oder deinen Fork.
