# ESP32-Casambi-Hass: Gruppen und Szenen Erweiterung

Dieses Paket ergänzt die Integration um:

- `GET /api/groups` und `GET /api/scenes` im DataCoordinator
- Casambi Gruppen als dimmbare `light` Entities
- Casambi Szenen als native Home Assistant `scene` Entities
- Casambi Szenen zusätzlich als `light` Control Entities für `on`, `off` und `level`
- Entity Services für `vertical`, `slider` und den atomaren Unit-State Endpoint

## Neue Entity Services

Nach dem Neustart stehen unter der Domain `esp32_casambi` bzw. auf Light-Entities folgende Services zur Verfügung:

```yaml
service: light.set_vertical
target:
  entity_id: light.deine_gruppe
service_data:
  value: 127
```

```yaml
service: light.set_slider
target:
  entity_id: light.deine_gruppe
service_data:
  value: 200
```

```yaml
service: light.set_unit_state
target:
  entity_id: light.deine_unit
service_data:
  state:
    dimmer0: 255
    dimmer1: 128
```

Hinweis: Home Assistant registriert Entity Services auf der `light` Platform. In Developer Tools werden sie deshalb in der Regel als Light Services angezeigt.

## Installation

1. Inhalt dieses ZIPs in dein Repository kopieren.
2. In Home Assistant die Integration aktualisieren oder den Custom Component Ordner ersetzen.
3. Home Assistant neu starten.
4. Integration neu laden oder bei Bedarf neu einrichten.

## Technische Annahmen

- Gruppen haben laut API keinen dokumentierten `/off` Endpoint. `turn_off` für Gruppen setzt deshalb `/api/groups/:id/level` auf `0`.
- Native HA Scenes unterstützen keine Helligkeit. Deshalb werden Szenen zusätzlich als Light-Control-Entities erstellt, damit `/on`, `/off` und `/level` nutzbar sind.
- Die API-Key Ableitung bleibt kompatibel mit `X-API-Key: sha256("casambi-api:" + password)`.
